package com.viewnext;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.viewnext.models.Provincia;

public class OperacionesFinales {

	public static void main(String[] args) {
		
		List<Provincia> lista = Arrays.asList(
				new Provincia("Madrid", 87, 67_886_543, 28, "Español", "Madrid", 90.67),
				new Provincia("Valencia", 45, 7876876, 46 , "Valenciano", "Valencia", 91.3),
				new Provincia("Coruña", 39, 54545, 9, "Gallego", "Coruña", 78.23),
				new Provincia("Toledo", 26, 3677556, 38, "Español", "Toledo", 35.17),
				new Provincia("Ourense", 29, 788866, 27, "Gallego", "Ourense", 28.68),
				new Provincia("Cuenca", 15, 986442, 16, "Español", "Cuenca", 34.12),
				new Provincia("Barcelona", 74, 556779, 8, "Catalan", "Barcelona", 97.25),
				new Provincia("Zamora", 28, 987656, 42, "Español", "Zamora", 56.34),
				new Provincia("Guipuzcoa", 35, 432223, 20, "Euskera", "San Sebastian", 48.23),
				new Provincia("Vizcaya", 48, 567654, 6, "Euskera", "Bilbao", 54.89)	
		);
		
		// Cual es la provincia con mayor numero de habitantes (max)
		Provincia maxHabitantes = lista.stream()
				.max(Comparator.comparing(Provincia::getPoblacion))
				.get();
		System.out.println(maxHabitantes);
		System.out.println("-------------------------------");
		
		
		// Cual es la provincia con menor densidad de poblacion (min)
		Provincia minDensidad = lista.stream()
				.min(Comparator.comparing(Provincia::getDensidadPoblacion))
				.get();
		System.out.println(minDensidad);
		System.out.println("-------------------------------");
		
		
		// Media de localidades por provincia (average)
		double mediaLocalidades = lista.stream()
				.mapToInt(prov -> prov.getNumLocalidades())
				.average()
				.getAsDouble();
		System.out.println(mediaLocalidades);
		System.out.println("-------------------------------");
		
		
		// Cuantas provincias tienen una densidad de poblacion inferior a 50 (count)
		long numProvPocaDensidad = lista.stream()
				.filter(prov -> prov.getDensidadPoblacion() < 50)
				.count();
		System.out.println(numProvPocaDensidad);
		System.out.println("-------------------------------");	
	
		
		// Suma de todos los habitantes por provincia (sum)
		int totalHabitantes = lista.stream()
				.mapToInt(prov -> prov.getPoblacion())
				.sum();
		System.out.println(totalHabitantes);
		System.out.println("-------------------------------");
		
		
		// collect -> crear una nueva coleccion
		// Crear una lista con las provincias que tienen como dialecto Español
		List<Provincia> espanyol = lista.stream()
				.filter(prov -> "Español".equals(prov.getDialecto()))
				.collect(Collectors.toList());
		espanyol.forEach(System.out::println);
		System.out.println("-------------------------------");
		
		
		// Generar una cadena de texto con el nombre de los distintos dialectos separados por |
		String dialectos = lista.stream()
				.map(prov -> prov.getDialecto())
				.distinct()
				.sorted()
				.collect(Collectors.joining(" | "));
		System.out.println(dialectos);
		System.out.println("-------------------------------");
		
		
		// Crear un mapa donde:
		//     - la clave sera el dialecto
		//     - el value sera una lista de las provincias con ese dialecto
		Map<String, List<Provincia>> mapaDialectos = lista.stream()
				.collect(Collectors.groupingBy(Provincia::getDialecto));
		mapaDialectos.forEach((k,v) -> {
			System.out.println("------------");
			System.out.println("Dialecto: " + k);
			System.out.println("------------");
			v.forEach(System.out::println);
		});
				
	}

}
