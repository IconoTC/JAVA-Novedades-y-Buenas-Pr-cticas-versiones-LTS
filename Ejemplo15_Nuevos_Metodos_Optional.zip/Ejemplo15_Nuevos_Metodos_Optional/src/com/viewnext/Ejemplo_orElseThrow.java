package com.viewnext;

import java.util.Optional;

public class Ejemplo_orElseThrow {

	public static void main(String[] args) {
		
		//Optional<String> optionalValue = Optional.ofNullable("Hola");
		Optional<String> optionalValue = Optional.ofNullable(null);
		
		// Si el optional esta vacio lanzamos una excepcion
		// Si no, mostraremos el valor
		// java.util.NoSuchElementException: No value present
		//String value = optionalValue.orElseThrow();
		
		// java.lang.RuntimeException: Valor nulo
		String value = optionalValue.orElseThrow(() -> new RuntimeException("Valor nulo"));
		System.out.println("Valor: " + value);

	}

}
