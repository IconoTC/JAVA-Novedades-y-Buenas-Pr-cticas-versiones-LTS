/**
 * 
 */
/**
 * 
 */
module Ejemplo18_Inferencia_tipos {
}