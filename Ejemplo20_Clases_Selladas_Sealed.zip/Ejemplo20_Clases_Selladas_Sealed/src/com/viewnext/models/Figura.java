package com.viewnext.models;

// Una clase declarada con sealed controla quien puede ser subclase de ella
// En nuestro ejemplo solo Circulo puede heredar
public abstract sealed class Figura permits Circulo{
	
	private int x;
	private int y;
	
	public Figura() {
		// TODO Auto-generated constructor stub
	}

	public Figura(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	abstract double calcularArea();

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "Figura [x=" + x + ", y=" + y + "]";
	}

}
