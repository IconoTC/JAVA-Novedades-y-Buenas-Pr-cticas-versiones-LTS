package com.viewnext.models;

public class SubCirculo extends Circulo{

}
