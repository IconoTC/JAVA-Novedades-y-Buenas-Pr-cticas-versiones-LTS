package com.viewnext;

import com.viewnext.models.Direccion;
import com.viewnext.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion dir1 = new Direccion("Mayor", 5, "Madrid");
		Empleado empleado1 = new Empleado(1, "Juan", 45_000, dir1);
		
		Empleado empleado2 = new Empleado(2, "Maria", 63_000, 
				new Direccion("Diagonal", 123, "Barcelona"));
		
		System.out.println(empleado1);
		System.out.println(empleado2);

	}

}

/*
 * Crear un proyecto Ejercicio_Modulos
 * en el paquete business crear Conversor(dolarToEuro, euroToDolar)
 * exportar el paquete
 * 
 * Crear un proyecto Ejercicio_Usar_Modulos
 * utilizar el conversor
 * */
