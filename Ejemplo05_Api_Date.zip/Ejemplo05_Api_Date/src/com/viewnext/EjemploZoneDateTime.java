package com.viewnext;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class EjemploZoneDateTime {

	public static void main(String[] args) {
		
		// Mostrar las zonas horarias
		System.out.println(ZoneId.getAvailableZoneIds());
		
		// Crear la zona horaria
		ZoneId USEast = ZoneId.of("America/New_York");
		
		// Hora en Madrid
		System.out.println("Ahora en Madrid: " + LocalTime.now());
		
		// Que hora es ahora mismo en New York
		System.out.println("Ahora en New York: " + ZonedDateTime.now(USEast));
		
		// Crear fecha y hora en España
		LocalDateTime spain = LocalDateTime.of(2024, Month.JUNE, 25, 16, 10);
		ZonedDateTime horaSpain = ZonedDateTime.of(spain, ZoneId.of("Europe/Madrid"));
		System.out.println("Hora en España: " + horaSpain);
		
		// Convertir esa fecha en horario New York
		ZonedDateTime newYork = ZonedDateTime.of(spain, USEast);
		System.out.println("Hora en New York: " + newYork);
		System.out.println("Diferencia horaria respecto al meridiano: " + newYork.getOffset());

	}

}
