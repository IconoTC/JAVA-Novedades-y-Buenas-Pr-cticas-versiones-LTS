package com.viewnext;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class EjemploLocalTime {

	public static void main(String[] args) {
		
		// Hora actual
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);
		
		// Solo horas:minutos
		System.out.println(ahora.truncatedTo(ChronoUnit.MINUTES));
		
		// Hora fin de clase
		LocalTime fin = LocalTime.of(20, 00);
		
		// Cuantas horas nos quedan de clase
		System.out.println("Cuanto queda? " + ahora.until(fin, ChronoUnit.HOURS));
		
		// Cuantos minutos nos quedan de clase
		System.out.println("Cuanto queda? " + ahora.until(fin, ChronoUnit.MINUTES));
		
		System.out.println(ahora.toSecondOfDay() + " segundos");
		System.out.println(ahora.toSecondOfDay() / 60 + " minutos");
		System.out.println(ahora.toSecondOfDay() / 60 / 60 + " horas");
	}

}
