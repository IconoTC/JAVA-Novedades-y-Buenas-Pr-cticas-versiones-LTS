package com.viewnext;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class AppMain {

	public static void main(String[] args) throws ScriptException {
		
		// Obtener una instancia del motor de JavaScript
		// a traves de la clase ScriptEngineManager
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine nashorn = manager.getEngineByName("nashorm");
		
		// Evaluar codigo JavaScript utilizando eval()
		//nashorn.eval("print('Hola que tal?')");
		
		// Cargar y ejecutar scripts
		nashorn.eval("load('hola.js')");

	}

}
