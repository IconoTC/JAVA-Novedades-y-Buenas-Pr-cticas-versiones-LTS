/**
 * 
 */
/**
 * 
 */
module Ejercicio_Usar_Modulos {
	
	requires Ejercicio_Modulos;
}