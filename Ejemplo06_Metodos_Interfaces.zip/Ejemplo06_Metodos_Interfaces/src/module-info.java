/**
 * 
 */
/**
 * 
 */
module Ejemplo06_Metodos_Interfaces {
}