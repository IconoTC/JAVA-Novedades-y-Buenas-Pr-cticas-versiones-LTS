package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo2_TareaAsincrona {

	public static void main(String[] args) throws InterruptedException {
		
		// Ejecutar una tarea asincrona
		CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
			// Todo lo que ponemos aqui, se ejecuta en un hilo aparte
			for(int i=1; i<=10; i++) {
				System.out.println("Tarea asincrona " + i);
			}
		});
		
		// Esto se ejecuta cuando termine la tarea asincrona
		future.thenRun(() -> System.out.println("Tarea finalizada"));
		
		Thread.sleep(5000);

	}

}
