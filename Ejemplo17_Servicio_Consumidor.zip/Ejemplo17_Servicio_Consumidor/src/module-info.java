/**
 * 
 */
/**
 * 
 */
module com.viewnext.consumidor {
	
	// modulo donde esta declarada la interface
	requires com.viewnext.servicio;
	
	// Necesito indicar cual es la interface a utilizar
	uses com.viewnext.interfaz.ItfzSaludo;
}