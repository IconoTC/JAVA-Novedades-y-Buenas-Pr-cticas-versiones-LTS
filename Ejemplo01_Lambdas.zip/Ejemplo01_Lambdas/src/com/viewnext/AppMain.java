package com.viewnext;

import com.viewnext.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis de lambda:  parametros -> cuerpo de la funcion
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros es obligatorio ponerlos entre ()
		// No es necesario poner el tipo a los parametros
		// al ser el cuerpo de la funcion una sola linea no necesita return ni {}
		ItfzFuncional lambda1 = (n, e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 36));
		
		ItfzFuncional lambda2 = (String nombre, int edad) -> "nombre: " + nombre + " edad: " + edad;
		System.out.println(lambda2.infoPersonas("Pepito", 36));
		
		// Si ponemos las llaves hay que poner el return
		ItfzFuncional lambda3 = (nombre, edad) -> {
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 36));
		
		// Si el cuerpo tiene mas de una linea es obligatorio las llaves
		ItfzFuncional lambda4 = (nombre, edad) -> {
			edad++;
			nombre = nombre.toUpperCase();
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 36));
		
		// Inferencia de tipos
		ItfzFuncional lambda5 = (var nombre, var edad) -> {
			edad++;
			nombre = nombre.toUpperCase();
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda5.infoPersonas("Pepito", 36));

	}

}
