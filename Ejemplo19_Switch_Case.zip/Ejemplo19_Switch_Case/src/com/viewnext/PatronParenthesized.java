package com.viewnext;

public class PatronParenthesized {

	public static void main(String[] args) {
		
		Object email = "pepito@gmail.com";
		
		switch (email) {
			case String s && s.length() > 0 && (s.contains("@") && s.contains(".")) -> System.out.println("Es un email");
		
		
		
			default -> throw new IllegalArgumentException("Unexpected value: " + email);
		}

	}

}
