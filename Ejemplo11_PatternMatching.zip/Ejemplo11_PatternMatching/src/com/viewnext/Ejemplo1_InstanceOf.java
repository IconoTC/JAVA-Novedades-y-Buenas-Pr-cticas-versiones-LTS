package com.viewnext;

public class Ejemplo1_InstanceOf {

	public static void main(String[] args) {
		
		//Object dato = "Prueba";
		Object dato = 25;
		
		// Antes de Java 11
		if (dato instanceof String) {
			String texto = (String) dato;  // Hacemos el casting
			System.out.println(texto.toUpperCase());
			System.out.println(texto.toLowerCase());
		}
		
		
		// A partir de Java 11
		// Se aplica el patron matching
		if (dato instanceof String texto) {  // Aplica la conversion o casting automatico
			System.out.println(texto.toUpperCase());
			System.out.println(texto.toLowerCase());
		} else if (dato instanceof Integer num) {
			System.out.println(num + 10);
		}

	}

}
