package com.viewnext;

import java.util.Scanner;

public class Practica_InstanceOf {

	public static void main(String[] args) {
		// Solicitar un dato al usuario por teclado
		// mostrar un mensaje si es texto, numero entero, numero real, char, boolean
		
		//Scanner sc = new Scanner(System.in);
		//System.out.println("Introduce un dato: ");
		Object dato = "hola";
		
		if (dato instanceof String texto) {
			System.out.println("El dato introducido " + texto + " es un texto");
		} else if (dato instanceof Integer numInt) {
			System.out.println("El dato introducido " + numInt + " es un numero entero");
		} else if (dato instanceof Double numDouble) {
			System.out.println("El dato introducido " + numDouble + " es un numero real");
		} else if (dato instanceof Character caracter) {
			System.out.println("El dato introducido " + caracter + " es un caracter");
		} else if (dato instanceof Boolean booleano) {
			System.out.println("El dato introducido " + booleano + " es un booleano");
		} else {
			System.out.println("Dato de otro tipo");
		}

	}

}
