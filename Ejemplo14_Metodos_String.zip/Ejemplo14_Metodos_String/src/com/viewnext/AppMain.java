package com.viewnext;

import java.util.List;
import java.util.stream.Collectors;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		// repeat
		System.out.println("-".repeat(20));
		System.out.println("*".repeat(20));
		System.out.println("ja".repeat(20));
		
		// strip
		String nombre = "     Juan   ";
		System.out.println(nombre + ".");
		
		// Quitar los espacios de izquierda y derecha
		System.out.println(nombre.strip() + ".");
		
		// Quitar solo los espacios de la izquierda
		System.out.println(nombre.stripLeading() + ".");
		
		// Quitar solo los espacios de la derecha
		System.out.println(nombre.stripTrailing() + ".");
		
		
		// lines
		String texto = "Hola\nque\ntal\n";
		System.out.println(texto);
		List<String> lista = texto.lines().collect(Collectors.toList());
		System.out.println(lista);
		
		texto.lines()
			.map(dato -> dato.toUpperCase())
			.forEach(System.out::println);
		
	}

}
