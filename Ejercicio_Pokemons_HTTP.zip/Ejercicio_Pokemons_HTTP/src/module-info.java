/**
 * 
 */
/**
 * 
 */
module Ejercicio_Pokemons_HTTP {
	requires org.json;
	requires java.net.http;
}