package com.viewnext;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws Exception {
		
		String url = "https://jsonplaceholder.typicode.com/users";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		// Contenedor cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		// Enviamos la peticion y recibimos la respuesta
		HttpResponse<String> respuesta = cliente.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		// Convertir ese String en un array de objetos JSON
		JSONArray jsonArray = new JSONArray(respuesta.body());
		
		// Recorrer ese array y por cada objeto generar un objeto JSON
		for (Object object : jsonArray) {
			JSONObject jsonObject = new JSONObject(object.toString());
			//System.out.println(jsonObject);
			
			// Mostrar los datos del usuario
			System.out.println("ID: " + jsonObject.getInt("id"));
			System.out.println("Nombre: " + jsonObject.getString("name"));
			System.out.println("Usuario: " + jsonObject.getString("username"));
			System.out.println("Email: " + jsonObject.getString("email"));
			
			JSONObject jsonDireccion = jsonObject.getJSONObject("address");
			System.out.println("Calle: " + jsonDireccion.getString("street"));
			System.out.println("Numero: " + jsonDireccion.getString("suite"));
			System.out.println("Ciudad: " + jsonDireccion.getString("city"));
			System.out.println("Codigo postal: " + jsonDireccion.getString("zipcode"));
			
			JSONObject jsonGeo = jsonDireccion.getJSONObject("geo");
			System.out.println("Latitud: " + jsonGeo.getString("lat"));
			System.out.println("Longitud: " + jsonGeo.getString("lng"));
			
			System.out.println("----------------------");
		}
				

	}

}
