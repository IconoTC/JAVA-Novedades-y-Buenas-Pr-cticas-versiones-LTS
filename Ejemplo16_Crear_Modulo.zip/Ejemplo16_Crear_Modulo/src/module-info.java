module com.viewnext.ejemplo16 {
	
	// exports paquete
	exports com.viewnext.models;
}