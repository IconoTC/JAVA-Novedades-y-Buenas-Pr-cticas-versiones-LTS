package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto existente
		System.out.println(dao.buscarProducto(3));
		System.out.println(dao.buscarProducto(3).get());
		
		
		// Buscar un producto que NO existe
		System.out.println(dao.buscarProducto(3767564));   // Optional.empty
		// java.util.NoSuchElementException: No value present
		//System.out.println(dao.buscarProducto(3767564).get());
		
		
		// Primera forma de evitar excepcion java.util.NoSuchElementException
		System.out.println(dao.buscarProducto(3767564).orElse(new Producto()));
		
		// Segunda forma de evitar excepciones
		Optional<Producto> opProducto = dao.buscarProducto(3767564);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Ese producto no existe");
		}
		
		if (opProducto.isEmpty()) {
			System.out.println("Ese producto no existe");
		} else {
			System.out.println(opProducto.get());		
		}

	}

}
