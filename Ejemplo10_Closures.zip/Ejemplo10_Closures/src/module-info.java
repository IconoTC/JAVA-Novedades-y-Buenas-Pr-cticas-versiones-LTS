/**
 * 
 */
/**
 * 
 */
module Ejemplo10_Closures {
}