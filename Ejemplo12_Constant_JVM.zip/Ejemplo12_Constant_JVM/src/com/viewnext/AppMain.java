package com.viewnext;

import java.lang.constant.ClassDesc;
import java.lang.constant.MethodTypeDesc;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un descriptor de clase para java.util.ArrayList
		ClassDesc clase = ClassDesc.of("java.util", "ArrayList");
		System.out.println("Nombre: " + clase.displayName());  // ArrayList
		System.out.println("Paquete: " + clase.packageName());	// java.util
		System.out.println("Descriptor de clase: " + clase.descriptorString());  // Ejemplo2_Switch_Case.java
		
		// Crear un descriptor de tipo de metodo
		// No recibe parametros y retorna un String
		MethodTypeDesc metodoString = MethodTypeDesc.of(ClassDesc.of("java.lang.String"));
		System.out.println(metodoString);  // [()String]
		
		// Crear un descriptor de tipo de metodo
		// Recibe como parametro un entero y retorna un double
		MethodTypeDesc metodoDouble = MethodTypeDesc.of(ClassDesc.of("java.lang.Double"), ClassDesc.of("java.lang.Integer"));
		System.out.println(metodoDouble);  // [(Integer)Double]
	}

}
