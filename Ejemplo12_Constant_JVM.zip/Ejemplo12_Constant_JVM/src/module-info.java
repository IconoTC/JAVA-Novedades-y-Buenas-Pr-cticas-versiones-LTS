/**
 * 
 */
/**
 * 
 */
module Ejemplo12_Constant_JVM {
}